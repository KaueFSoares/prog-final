package model;

public class Comida extends Produto {

    private boolean salgado;
    private boolean acompanhamento;
    private boolean quente;

    public Comida(String nome, double preco, boolean salgado, boolean acompanhamento, boolean quente) {
        super(nome, preco);
        this.salgado = salgado;
        this.acompanhamento = acompanhamento;
        this.quente = quente;
    }
}
