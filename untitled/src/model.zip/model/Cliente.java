package model;

import java.util.List;

public class Cliente {

    private final String nome;
    private final List<Produto> cardapio;

    public Cliente(String nome, List<Produto> cardapio) {
        this.nome = nome;
        this.cardapio = cardapio;
    }

}
