package ui;

import model.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class CardapioFrame extends JFrame {

    private Cliente cliente;
    private List<ItemPedido> itensSelecionados = new ArrayList<>();
    private JPanel pedidoPanel;
    private DefaultListModel<ItemPedido> pedidoListModel;

    public CardapioFrame(Cliente cliente) {
        this.cliente = cliente;

        setTitle(cliente.getNome());
        setSize(1000, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Painel dos produtos
        JPanel produtosPanel = new JPanel(new GridLayout(0, 3, 20, 20));
        produtosPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        for (Produto produto : cliente.getCardapio()) {
            JPanel produtoCard = criarProdutoCard(produto);
            produtosPanel.add(produtoCard);
        }

        JScrollPane scrollProdutos = new JScrollPane(produtosPanel);
        add(scrollProdutos, BorderLayout.CENTER);

        // Painel do pedido
        pedidoPanel = new JPanel();
        pedidoPanel.setLayout(new BoxLayout(pedidoPanel, BoxLayout.Y_AXIS));
        pedidoPanel.setBorder(BorderFactory.createTitledBorder("Seu Pedido"));

        pedidoListModel = new DefaultListModel<>();
        JList<ItemPedido> pedidoList = new JList<>(pedidoListModel);
        pedidoPanel.add(new JScrollPane(pedidoList));

        JButton finalizarPedidoButton = new JButton("Finalizar Pedido");
        finalizarPedidoButton.setBackground(Color.RED);
        finalizarPedidoButton.setForeground(Color.WHITE);
        finalizarPedidoButton.setFont(new Font("Arial", Font.BOLD, 20));

        finalizarPedidoButton.addActionListener(e -> {
            if (!itensSelecionados.isEmpty()) {
                Pedido pedido = new Pedido("Pedido #" + (int) (Math.random() * 1000), new ArrayList<>(itensSelecionados));
                new PedidosFrame(pedido).setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Seu pedido está vazio.");
            }
        });

        pedidoPanel.add(finalizarPedidoButton);

        add(pedidoPanel, BorderLayout.SOUTH);
    }

    private JPanel criarProdutoCard(Produto produto) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setPreferredSize(new Dimension(300, 300));

        String imagemPath = "resources/images/" + produto.getNome().toLowerCase().replace(" ", "-") + ".png";
        ImageIcon icon = new ImageIcon(imagemPath);
        JLabel imagemLabel = new JLabel(icon);
        imagemLabel.setPreferredSize(new Dimension(300, 300));
        imagemLabel.setHorizontalAlignment(JLabel.CENTER);

        JButton addButton = new JButton("+");
        addButton.setFont(new Font("Arial", Font.BOLD, 20));
        addButton.setBackground(Color.CYAN);
        addButton.setForeground(Color.WHITE);

        addButton.addActionListener(e -> adicionarProduto(produto));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(addButton);

        panel.add(imagemLabel, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.NORTH);

        return panel;
    }

    private void adicionarProduto(Produto produto) {
        ItemPedido item = new ItemPedido(produto, 1);
        itensSelecionados.add(item);
        pedidoListModel.addElement(item);
    }
}
